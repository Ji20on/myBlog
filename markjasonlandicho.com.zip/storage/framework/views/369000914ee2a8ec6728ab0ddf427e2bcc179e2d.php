  
  <?php $__env->startSection('title','Mark Jason Landicho'); ?>
  <?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="container myworks">
    <div class="row">
      <?php $__currentLoopData = App\Portfolio::get_portfolios_post(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allPort): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-12 col-md-6 col-lg-4 hvr-grow" data-wow-duration="2s" data-wow-delay="5s">
        <a href="<?php echo e(route('port_link',['slug'=>$allPort->slug])); ?>">
          <div class="card">
            <img class="card-img-top img-fluid" src="<?php echo e(asset($allPort->port_thumb)); ?>" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title"><?php echo e(str_limit($allPort->title, 20)); ?></h5>
              <p class="card-text"><?php echo e(str_limit($allPort->category, 20)); ?></p>
            </div>
          </div>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>