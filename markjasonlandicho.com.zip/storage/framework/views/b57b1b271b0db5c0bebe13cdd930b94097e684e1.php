<?php $__env->startSection('title','Mark Jason Landicho'); ?>
<?php $__env->startSection('content'); ?>

<!-- header -->
<header>
  
  <svg id="wave" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 91">
    <path class="cls-1" d="M1399.5,149.5" transform="translate(0 -209)"/><path class="cls-2" d="M0,261s281-80,600-25,470,40,550,25,250-52,250-52v91H0Z" transform="translate(0 -209)"/>
  </svg>
  <div class="container-fluid front-container">
    <div class="row">
      <div class="col col-xs-12 col-sm-12 col-md-6 name-wrapper">
        <h1 class="wow slideInLeft hvr-wobble-skew">Hi! Im Mark Jason Landicho</h1>
        <h3 class="wow slideInLeft hvr-wobble-skew">Front-End Web Developer</h3>
      </div>
      <div class="col col-sm-12 col-md-6 svg-wrapper">
        <?php echo $__env->make('partials.logo-svg', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  </div>
  
  <div id="particles-js"> 
  </div>

</header>




<!-- myworks-->
<div class="container myworks">
  <h3 class="text-center">my latest works</h3>
  <hr class="style-one"><br>
  <div class="row">
    <?php $__currentLoopData = App\Portfolio::latest_port(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 hvr-grow" data-wow-duration="2s" data-wow-delay="5s">
      <a href="<?php echo e(route('port_link',['slug'=>$portfolio->slug])); ?>">
        <div class="card">
          <img class="card-img-top" src="<?php echo e(asset($portfolio->port_thumb)); ?>" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title"><?php echo e(str_limit($portfolio->title, 20)); ?></h5>
            <p class="card-text"><?php echo e(str_limit($portfolio->category, 20)); ?></p>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>






<!-- contact -->
<div id="contact-me" class="container contact-me">
  <h3 class="text-center">CONTACT ME</h3>
  <hr class="style-one">
  <div class="row">
    <div class="col-md-6 mx-auto">
      
      <?php if(count($errors)>0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>;
      <div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e($error); ?></strong>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
      <?php if(Session::has('msg')): ?>
      <div class="alert alert-dismissible alert-success">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(Session::get('msg')); ?></strong>
      </div>
      <?php endif; ?>
      <form action="send-message" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <!-- Name -->
          <input type="text" name="name" id="name" class="textform form-control" placeholder="Name *" maxlength="100" required="">
        </div>
        <div class="form-group">
         <!-- Email -->
         <input type="email" name="email" id="email" class="textform form-control" placeholder="Email *" maxlength="100" required="">
       </div>
       <div class="form-group">
        <!-- phone -->
        <input type="text" name="phone" id="phone" class="textform form-control" placeholder="Phone" maxlength="100">
      </div>
      <div class="form-group">
       <!-- Comment -->
       <textarea name="comment" id="comment" class="form-control comment" placeholder="Comment" maxlength="400"></textarea>
     </div>
     <div class="form-group full-width pull-right">
       <button type="submit" class="btn btn-primary">
         Send Message
       </button>
     </div>
   </form>
 </div>
</div>
</div>







<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
</script>

<script>
  particlesJS.load('particles-js','js/particles.json');
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>