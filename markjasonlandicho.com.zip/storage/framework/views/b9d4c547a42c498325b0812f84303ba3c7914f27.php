<?php $__env->startSection('title','admin'); ?>
<?php $__env->startSection('content'); ?>




<div class="container manage-blog">
  
  <?php if(count($errors)>0): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>;
  <div class="alert alert-dismissible alert-danger">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong><?php echo e($error); ?></strong>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  
  <?php if(Session::has('msg')): ?>
  <div class="alert alert-dismissible alert-success">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong><?php echo e(Session::get('msg')); ?></strong>
  </div>
  <?php endif; ?>
  <h3>Edit Blog</h3> <br> <br>
  <form action="<?php echo e(route('edit-save-blog',['id'=> $blog->id])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>

    <div class="row">
      <div class="col col-md-8">
        <div class="form-group">
         <input name="id" value="<?php echo e($blog->id); ?>" type="hidden" class="form-control" id="blog-title" placeholder="Enter Post Title">
         <input name="title" value="<?php echo e($blog->title); ?>" type="text" class="form-control" id="blog-title" placeholder="Enter Post Title">
       </div>
       <div class="form-group">
        <input name="author" value="<?php echo e($blog->author); ?>" type="text" class="form-control" id="blog-author" placeholder="Enter Post author">
      </div>
      <div class="form-group">
        <textarea name="content" class="form-control wysyg_editor" id="content" rows="10" placeholder="Content here..."><?php echo e($blog->description); ?></textarea>
      </div>
    </div>
    <div class="col col-md-4">
     <div class="form-group">
      <label for="blog-thumb">Fearured Image</label>
      <input name="blogthumb" type="text" class="form-control file" value="<?php echo e(asset($blog->blog_thumb)); ?>" id="blog-thumb" placeholder="Paste img URL here." aria-describedby="fileHelp">
        <img class="img-fluid" src="<?php echo e(asset($blog->blog_thumb)); ?>" id="preview">
    </div>
    <div class="form-group">
      <button type="submit" class="btn btn-primary pull-right">Save</button>
    </div>
  </div>
</div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>