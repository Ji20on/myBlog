 
 <?php $__env->startSection('title','Mark Jason Landicho'); ?>
 <?php $__env->startSection('content'); ?>

 <?php echo $__env->make('partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <input type="hidden" id="link-page" value="blog">
 <div class="container blog-wrap">
 	<div class="row">
 		<div class="col col-md-8 offset-md-2 blog-card">
 			<h2><?php echo e($blog->title); ?></h2>
 			<hr>
 			<h5 class="card-title">By <?php echo e($blog->author); ?><span class="pull-right"><?php echo e($blog->created_at->format('M d, Y | h:i A')); ?></span></h5>
 			<img class="img-fluid" width="100%" src="<?php echo e(asset($blog->blog_thumb)); ?>"> <br>  <br>
 			<div class="card-body">
 				<?php echo $blog->description; ?>

 			</div>
 		</div>
 	</div>
 </div>

 <div class="container comments-section">
 	<div class="row">
 		<div class="col col-md-8 offset-md-2">

 			<div id="disqus_thread"></div>
 			<script>

/**
*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/

var disqus_config = function () {
this.page.url = 'http://localhost/mywebsite/blog-page.php'; // Replace PAGE_URL with your page's canonical URL variable
this.page.identifier = 'blog-page'; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
};

(function() { // DON'T EDIT BELOW THIS LINE
	var d = document, s = d.createElement('script');
	s.src = 'https://markjasonlandicho.disqus.com/embed.js';
	s.setAttribute('data-timestamp', +new Date());
	(d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
</div>
</div>
</div>

<div class="container more-blogs">
	<h3 class="text-center">More Blogs</h3>
	<hr class="style-one"><br>
	<div class="row">
		<?php $__currentLoopData = App\Blog::out_of_blog($blog->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outOfB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-4">
			<a href="<?php echo e(route('blog_link',['slug'=>$outOfB->slug])); ?>">
				<div class="card">
					<img class="card-img-top" src="<?php echo e(asset($outOfB->blog_thumb)); ?>" alt="Card image cap">
					<div class="card-body">
						<h5 class="card-title"><?php echo e(str_limit($outOfB->title, 20)); ?></h5>
						<p class="card-text"><?php echo e(str_limit($outOfB->author, 20)); ?></p>
					</div>
				</div>
			</a>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>