<?php $__env->startSection('title','admin'); ?>
<?php $__env->startSection('content'); ?>


<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Overview</li>
		</ol>
		<!-- /.container-fluid -->
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>