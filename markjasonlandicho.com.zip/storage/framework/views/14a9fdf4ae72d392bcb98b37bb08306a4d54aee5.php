  
  <?php $__env->startSection('title','Mark Jason Landicho'); ?>
  <?php $__env->startSection('content'); ?>

  <?php echo $__env->make('partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="container all-blog">
  	<div class="row">
  		<?php $__currentLoopData = App\Blog::get_blog_post(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		<div class="col col-md-6">
  			<div class="card blog-card">
  				<h2><?php echo e(str_limit($allBlog->title, 20)); ?></h2>
  				<hr>
  				<h5 class="card-title"><?php echo e(str_limit($allBlog->author, 20)); ?><span class="pull-right"><?php echo e($allBlog->created_at->format('M d, Y | h:i A')); ?></span></h5>
  				<img class="img-fluid" src="<?php echo e(asset($allBlog->blog_thumb)); ?>"> <br>  <br>
  				<div class="card-body">
  					<?php echo str_limit($allBlog->description,200); ?> <br>
  				</div>
  				<div class="car-footer">
  					<a href="<?php echo e(route('blog_link',['slug'=>$allBlog->slug])); ?>" class="btn btn-primary pull-right">Read More</a>
  				</div>
  			</div>
  		</div>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  	</div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>