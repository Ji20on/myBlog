  
  <?php $__env->startSection('title','Mark Jason Landicho'); ?>
  <?php $__env->startSection('content'); ?>


 <?php echo $__env->make('partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <input type="hidden" id="link-page" value="port">
  <div class="container port-details">
  	<div class="row">
  		<div class="col-sm-12 col-md-6">
  			<h2><?php echo e($portfolio->title); ?></h2>
  			<hr>
  			<span class=""><?php echo e($portfolio->category); ?></span> <br><br>
  			<p><?php echo e($portfolio->description); ?></p>
  		</div>
  		<div class="col-sm-12 col-md-6">
  			<img class="img-fluid" src="<?php echo e(asset($portfolio->port_thumb)); ?>">
  		</div>
  	</div>
  </div>

  
  <div class="container port-content">
        <?php echo $portfolio->content; ?>

  </div>

  <div class="container more-port">
  	<h3 class="text-center">More Portfolios</h3>
  	<hr class="style-one"><br>
  	<div class="row">
      <?php $__currentLoopData = App\Portfolio::out_of_port($portfolio->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outOfP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
       <a href="<?php echo e(route('port_link',['slug'=>$outOfP->slug])); ?>">
        <div class="card">
         <img class="card-img-top" src="<?php echo e(asset($outOfP->port_thumb)); ?>" alt="Card image cap">
         <div class="card-body">
          <h5 class="card-title"><?php echo e(str_limit($outOfP->title, 20)); ?></h5>
          <p class="card-text"><?php echo e(str_limit($outOfP->category, 20)); ?></p>
        </div>
      </div>
    </a>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>