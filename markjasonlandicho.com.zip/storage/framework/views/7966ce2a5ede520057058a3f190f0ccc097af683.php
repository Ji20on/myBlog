<h1>Message</h1>
<ul>
	<li>Name: <?php echo e($name); ?></li>
	<li>Email: <?php echo e($email); ?></li>
	<li>Phone: <?php echo e($phone); ?></li>
	<li>Comment: <?php echo e($comment); ?></li>
</ul>