<!-- footer -->
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-6 copyright-wrapper">
       <span class="text-center copyright">&#9400; 2018 MARK JASON LANDICHO</span>
     </div>
     <div class="col-md-6">
      <ul class="social-icon">
        <li><a  href="" data-toggle="tooltip" data-placement="top" title="Facebook "><i class="fa fa-facebook-f"></i></a></li>
        <li><a  href="" data-toggle="tooltip" data-placement="top" title="Instagram "><i class="fa fa-instagram"></i></a></li>
        <li><a  href="" data-toggle="tooltip" data-placement="top" title="LinkedIn"><i class="fa fa-linkedin"></i></a></li>
        <li><a  href="" data-toggle="tooltip" data-placement="top" title="Gmail"><i class="fa fa-envelope"></i></a></li>
      </ul>
    </div>
  </div>
</div>
</footer>