<?php $__env->startSection('title','admin'); ?>
<?php $__env->startSection('content'); ?>


<div class="container manage-port">
  
  <?php if(count($errors)>0): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>;
  <div class="alert alert-dismissible alert-danger">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong><?php echo e($error); ?></strong>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  
  <?php if(Session::has('msg')): ?>
  <div class="alert alert-dismissible alert-success">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong><?php echo e(Session::get('msg')); ?></strong>
  </div>
  <?php endif; ?>

  <h3>Edit Portfolio</h3> <br> <br>
  <form action="<?php echo e(route('edit-save-port',['id'=> $portfolio->id])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <div class="row">
      <div class="col col-md-9">
        <div class="form-group">
          <input name="id" value="<?php echo e($portfolio->id); ?>" type="hidden" class="form-control" id="blog-title" placeholder="Enter Post Title">
          <input name="title" value="<?php echo e($portfolio->title); ?>" type="text" class="form-control" id="port-title" placeholder="Enter Portfolio Title">
        </div>
        <div class="form-group">
          <input name="category" value="<?php echo e($portfolio->category); ?>" type="text" class="form-control" id="port-category" placeholder="Enter Portfolio Category">
        </div>
        <div class="form-group">
          <textarea name="desc" class="form-control" id="port-desc" rows="3" placeholder="Content here...">
            <?php echo e($portfolio->description); ?></textarea>
          </div>
          <div class="form-group">
            <textarea name="content" class="form-control wysyg_editor" id="port-content" rows="10" placeholder="Content here..."><?php echo e($portfolio->content); ?></textarea>
          </div>
        </div>
        <div class="col col-md-3">
         <div class="form-group">
          <label for="port-thumb">Fearured Image</label>
          <input name="portthumb" type="text" class="form-control-file" value="<?php echo e($portfolio->port_thumb); ?>" id="port-thumb" aria-describedby="fileHelp">
          <img id="preview" class="img-fluid" src="<?php echo e(asset($portfolio->port_thumb)); ?>">
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary pull-right">Save</button>
        </div>
      </div>
    </div>
  </div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>