<div class="container bc-wrap">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="/">Home</a></li>
		<?php if(URL::current() == 'http://localhost:8000/about'): ?>
		<li class="breadcrumb-item active"><a href="<?php echo e(route('about')); ?>">About Me</a></li>
		<?php elseif(URL::current() == 'http://localhost:8000/portfolio'): ?>
		<li class="breadcrumb-item active"><a href="#">My Works</a></li>
		<?php elseif(isset($portfolio)): ?>
		<li class="breadcrumb-item active"><a href="<?php echo e(route('all-port')); ?>">My Works</a></li>
		<li class="breadcrumb-item active"><a href="#"><?php echo e($portfolio->title); ?></a></li>
		<?php elseif(URL::current() == 'http://localhost:8000/blog'): ?>
		<li class="breadcrumb-item active"><a href="#">My Blogs</a></li>
		<?php elseif(isset($blog)): ?>
		<li class="breadcrumb-item active"><a href="<?php echo e(route('all-blog')); ?>">My Blogs</a></li>
		<li class="breadcrumb-item active"><a href="#"><?php echo e($blog->title); ?></a></li>
		<?php endif; ?>
	</ol>
</div>