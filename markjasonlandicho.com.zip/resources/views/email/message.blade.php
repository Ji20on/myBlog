<h1>Message</h1>
<ul>
	<li>Name: {{$name}}</li>
	<li>Email: {{$email}}</li>
	<li>Phone: {{$phone}}</li>
	<li>Comment: {{$comment}}</li>
</ul>