
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <span class="copyright">&#9400; Copyright 2018 MJL</span> |
        <span class="copyright">All Rights Reserved. By Mark Jason Landicho</span>
      </div>
      <div class="col-md-6">
        <div class="social-link float-lg-right">
          <a id="social-fb" class="social"  href="https://www.facebook.com/Ji20on" target="_new" data-toggle="tooltip" data-placement="top" title="Facebook "><i class="fa fa-facebook-f fa-2x"></i></a>
          <a id="social-ins" class="social"  href="https://www.instagram.com/ji20on/?hl=en" target="_new" data-toggle="tooltip" data-placement="top" title="Instagram "><i class="fa fa-instagram fa-2x"></i></a>
          <a id="social-lin" class="social"  href="https://www.linkedin.com/in/mark-jason-landicho-bb5ab1138/" target="_new" data-toggle="tooltip" data-placement="top" title="LinkedIn"><i class="fa fa-linkedin fa-2x"></i></a>
          <a id="social-em" class="social"  href="https://plus.google.com/u/0/100269729438138254620" target="_new" data-toggle="tooltip" data-placement="top" title="Gmail"><i class="fa fa-envelope fa-2x"></i></a>
        </div>
      </div>
    </div>
  </footer>
